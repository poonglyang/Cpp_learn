#include "AutoSelectBingo.h"
#include <queue>
// �ڵ� ����


AutoSelectBingo::AutoSelectBingo(int size) : Bingo(size)
{
}

AutoSelectBingo::~AutoSelectBingo()
{
}


int AutoSelectBingo::AutoSelect()
{
	int autoSelect[2];

	for (int col = 0; col < size; col++) {
		for (int row = 0; row < size; row++) {

		}
	}

	return autoSelect[0];
}
